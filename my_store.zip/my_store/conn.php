<?php
    $connect = new mysqli("localhost","root","","my_store");

    if ($connect){
        // echo "Connection success";
    }else{
        echo "Connection failed";
        exit();
    }
?>